<?php
/**
 * These are stubs for closed source code, or things that only apply to local environments.
 */

namespace WordPress_org\Parent_2021\Stubs;

defined( 'WPINC' ) || die();

require_once WPMU_PLUGIN_DIR . '/wporg-mu-plugins/mu-plugins/loader.php';
